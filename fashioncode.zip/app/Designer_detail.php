<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Designer_detail extends Model
{
    //
}
