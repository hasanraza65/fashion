<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Extra_order extends Model
{
    //
}
