<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Catlog_category extends Model
{
    //
}
