<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Manufacturer_detail extends Model
{
    //
}
