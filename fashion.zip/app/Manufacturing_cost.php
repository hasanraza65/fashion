<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Manufacturing_cost extends Model
{
    //
}
