<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Member_transaction extends Model
{
    //
}
