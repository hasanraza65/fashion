<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductSizes extends Model
{
    protected $table = "product_sizes";
    protected $guarded = [];
}
