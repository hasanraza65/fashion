<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Catlog extends Model
{
    //
}
